# REFERENCES
# Inputting values: https://www.w3schools.com/python/python_user_input.asp
# Working with negative numbers: https://www.geeksforgeeks.org/working-with-negative-numbers-in-python/
# Looping until valid input: https://blog.heycoach.in/handling-invalid-input-in-python/
# Checking numbers including negative and decimals: https://stackoverflow.com/questions/78497026/how-to-check-if-an-input-is-an-integer-including-negative-and-decimal-inputs
# Removing trailing zeroes: https://stackoverflow.com/questions/2440692/formatting-floats-without-trailing-zeros
# Getting positions at strings: https://www.w3schools.com/python/python_strings.asp

# ENHANCEMENT: Dedicated function added to find if a number is valid or not
def is_valid_num(num):
    try:
        float(num)  # the given value into a float to detect it as a number
        return True
    except ValueError:
        return False

# ENHANCEMENT: Dedicated function necessary to save on reprinting the same message
# Function to remind the user to print numbers in a proper format
def print_valid_format(num):
    print(f'The input \"{num}\" is not a valid input for the first number.\n')
    print('Please enter a valid number in any of the following formats, with X and Y being any number:')
    print("X")
    print("+X")
    print("-X")
    print(".X")
    print("X.")
    print("X.Y")
    print("+.X")
    print("+X.")
    print("+X.Y")
    print("-.X")
    print("-X.")
    print("-X.Y\n")

# ENHANCEMENT: Dedicated function to format the numbers
def format_num(num, theResult):
    num = f"{float(num):g}"               # Removes all trailing zeros
    if float(num) < 0 and not theResult:
        num = f"({num})"                  # Formats negative numbers to be in parentheses for num1 and num2
    elif float(num) == 0:
        num = "0"                         # Formats all numbers as zero as "0"
    return num

# ENHANCEMENT: Dedicated function added to print results similarly
def print_results(num1, num2, sign, result):
    print("\nRESULTS:")
    print(f"{format_num(num1, False)} {sign} {format_num(num2, False)} = {format_num(result, True)}")

# The main class to control the menu and compute two inputted numbers
if __name__ == '__main__':
    while True:
        # Print menu
        print("----------------")
        print("- 1)Add -")
        print("- 2)Subtract -")
        print("- 3)Multiply -")
        print("- 4)Division -")  # ENHANCEMENT: Added division
        print("- 5)Modulo -")    # ENHANCEMENT: Added modulo
        print("- 6)Exit -")
        print("----------------")

        # User inputs
        choice = input()

        # ENHANCEMENT: Checks for bad inputs within a fewer amount of lines
        # Checks for valid input based on the proper numeric value and choice
        if not is_valid_num(choice)\
                or float(choice) < 1 or float(choice) > 6\
                or (int(float(choice)) != float(f"{float(choice):g}")):  # ENHANCEMENT: Acceptance of floats if they're whole numbers
            print()
            print(f"The input \"{choice}\" is not a valid input for the menu choice.")

        # Exits on input 5
        elif int(float(choice)) == 6:
            print("Goodbye.")
            break

        # Requests for two numbers
        else:

            # Request for first input until it is valid
            while True:
                num1 = input("Enter your first number.\n")
                if is_valid_num(num1):        # Checks for valid input
                    break
                else:
                    print_valid_format(num1)  # Notification for invalid input

            # Request for second input until it is valid
            while True:
                num2 = input("Enter your second number.\n")
                if (int(float(choice)) == 4 or int(float(choice)) == 5)\
                        and float(num2) == 0:                                               # Prevents the user from using 0 as the divisor
                    print(f"The input \"{num2}\" is not a valid input for the divisor.\n")
                elif is_valid_num(num2):                                                    # Checks for valid input
                    break
                else:
                    print_valid_format(num2)                                                # Notification for invalid input

            # ENHANCEMENTS: Cleaner direction of adding inputs using fewer lines

            # If the user adds
            if int(float(choice)) == 1:
                result = float(num1) + float(num2)      # Save results
                print_results(num1, num2, "+", result)  # Print results

            # If the user subtracts
            elif int(float(choice)) == 2:
                result = float(num1) - float(num2)      # Save results
                print_results(num1, num2, "-", result)  # Print results

            # If the user multiplies
            elif int(float(choice)) == 3:
                result = float(num1) * float(num2)      # Save results
                print_results(num1, num2, "*", result)  # Print results

            # ENHANCEMENT: Added division
            # If the user divides
            elif int(float(choice)) == 4:
                result = float(num1) / float(num2)      # Save results
                print_results(num1, num2, "/", result)  # Print results

            # ENHANCEMENT: Added modulo
            # If the user utilizes modulo
            elif int(float(choice)) == 5:
                result = float(num1) % float(num2)      # Save results
                print_results(num1, num2, "%", result)  # Print results