// ProjectTwoCS410.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <iostream>
#include <limits>        // For numeric limits
#include <cmath>         // For absolute value
#include <string>        // For string
#include <stdlib.h>      // For strtod

using namespace std;

// Added function to remove trailing zeroes
// REFERENCE FOR REMOVING TRAILING ZEROES:
// https://stackoverflow.com/questions/13686482/c11-stdto-stringdouble-no-trailing-zeros
string noTrailingZeroes(const string num)
{
    string result = num;

    result.erase(result.find_last_not_of('0') + 1, string::npos);
    result.erase(result.find_last_not_of('.') + 1, string::npos);

    return result;
}

// VULNERABILITY FIXED: Added function to check if num1 or num2 is a number, as num1 and num2 are strings
// REFERENCES FOR CHECKING IF A STRING IS A NUMBER:
// https://stackoverflow.com/questions/4654636/how-to-determine-if-a-string-is-a-number-with-c
// https://www.tutorialspoint.com/cplusplus-program-to-check-if-a-string-is-numeric
// https://stackoverflow.com/questions/29169153/how-do-i-verify-a-string-is-valid-double-even-if-it-has-a-point-in-it
bool isNumber(const string& s)
{
    char* end = nullptr;
    double val = strtod(s.c_str(), &end);
    return end != s.c_str() && *end == '\0' && val != HUGE_VAL;
}

int main()
{
    // Initialized variables for inputtable numbers
    // VULNERABILITY FIXED: All numbers are strings instead of integers or doubles, as making them as integers lead to infinite loops for wrong inputs (IE: a) and doubles cause taking multiple inputs in one line (IE: 1.1)
    string input;   // Input as string to take one input only
    string num1;    // For the fist number for an equation to be converted into a double calculation
    string num2;    // For the second number for an equation to be converted into a double for calculation

    // To format negative numbers as parantheses, if necessary
    string negNum1;
    string negNum2;

    // VULNERABILITY FIXED: Exit by choice 4 as intended, rather than 5
    while (input != "4")
    {
        // User inputs choices
        // VULNERABILITY FIXED: Input should be regarded as an number or a valid choice
        // REFERENCES FOR HANDLING BAD INPUT:
        // https://www.learncpp.com/cpp-tutorial/stdcin-and-handling-invalid-input/
        // https://www.geeksforgeeks.org/ask-user-input-until-correct-input-is-received-in-cpp/
        while (true)
        {
            // Menu displays
            cout << "----------------\n";
            cout << "- 1)Add -\n";
            cout << "- 2)Subtract -\n";
            cout << "- 3)Multiply -\n";
            cout << "- 4)Exit -\n";
            cout << "----------------\n";

            getline(cin, input);                                                          // VULNERABILITY FIXED: input gets taken as one line only

            if (((input == "1") || (input == "2")) || ((input == "3") || (input == "4"))) // VULNERABILITY FIXED: Assurance of no bad inputs, make sure to only enter 1, 2, 3, or 4
            {
                break;
            }
            else if (input == "")
            {
                cout << "You need to enter a valid input for the menu choice.\n";                      // VULNERABILITY FIXED: Notificaiton letting user know what they inputted nothing
            }
            else
            {
                cout << "\nThe input \"" << input << "\" is not a valid input for the menu choice.\n"; // Notificaiton letting user know what they inputted is invalid
            }
        }

        if (input == "4") // User inputting choice 4 will ignore the rest of the choices and end the program
        {
            cout << "\nGoodbye.\n";
            break;
        }
        else             // User will enter two more numbers to be added, subtracted, or multiplied. Saves redundancy on reprogramming inputting the two numbers.
        {
            cout << "\nEnter your first number.\n";
            while (true)
            {
                getline(cin, num1);                                                      // VULNERABILITY FIXED: num1 gets taken as one line only

                if (num1 == "")
                {
                     cout << "You need to enter a valid input for the first number.\n";  // VUNLERABILITY FIXED: Notificaiton letting user know what they inputted nothing
                }
                else if (isNumber(num1) == false)                                        // VULNERABILITY FIXED: Assurance of no bad inputs, this time for checking if a string is not a number
                {
                    // VULNERABILITY FIXED: Updated message to explain every valid number format.
                    cout << "\nThe input \"" << num1 << "\" is not a valid input for the first number.\n"; // Notificaiton letting user know what they inputted is invalid
                    cout << "\nPlease enter a valid number in any of the following formats, with X and Y being any number:";
                    cout << "\nX";
                    cout << "\n+X";
                    cout << "\n-X";
                    cout << "\n.X";
                    cout << "\nX.";
                    cout << "\nX.Y";
                    cout << "\n+.X";
                    cout << "\n+X.";
                    cout << "\n+X.Y";
                    cout << "\n-.X";
                    cout << "\n-X.";
                    cout << "\n-X.Y\n\n";
                }
                else
                {
                    break;
                }
            }

            cout << "\nEnter your second number.\n";
            while (true)
            {
                getline(cin, num2);                                                      // VULNERABILITY FIXED: num1 gets taken as one line only

                if (num2 == "")
                {
                    cout << "You need to enter a valid input for the second number.\n";  // VUNLERABILITY FIXED: Notificaiton letting user know what they inputted nothing
                }
                else if (isNumber(num2) == false)                                        // VULNERABILITY FIXED: Assurance of no bad inputs, this time for checking if a string is not a number
                {
                    // VULNERABILITY FIXED: Updated message to explain every valid number format.
                    cout << "\nThe input \"" << num2 << "\" is not a valid input for the second number.\n"; // Notificaiton letting user know what they inputted is invalid
                    cout << "\nPlease enter a valid number in any of the following formats, with X and Y being any number:";
                    cout << "\nX";
                    cout << "\n+X";
                    cout << "\n-X";
                    cout << "\n.X";
                    cout << "\nX.";
                    cout << "\nX.Y";
                    cout << "\n+.X";
                    cout << "\n+X.";
                    cout << "\n+X.Y";
                    cout << "\n-.X";
                    cout << "\n-X.";
                    cout << "\n-X.Y\n\n";
                }
                else
                {
                    break;
                }
            }
        }

        // REFERENCE FOR STOD:
        // https://www.geeksforgeeks.org/cpp-program-for-string-to-double-conversion/
        
        // Formats negative numbers as necessary
        if (stod(num1) < 0)
        {
            negNum1 = "(" + noTrailingZeroes(to_string(stod(num1))) + ")";
        }
        else if (stod(num1) == 0)
        {
            negNum1 = "0";
        }
        else
        {
            negNum1 = noTrailingZeroes(to_string(stod(num1)));
        }

        if (stod(num2) < 0)
        {
            negNum2 = "(" + noTrailingZeroes(to_string(stod(num2))) + ")";
        }
        else if (stod(num2) == 0)
        {
            negNum2 = "0";
        }
        else
        {
            negNum2 = noTrailingZeroes(to_string(stod(num2)));
        }
        
        if (input == "1")      // If user chose to add
        {
            // Added functionality to make 0 display as 0, as -0 is not really necessary
            // VULNERABILITY FIXED: Addition as intended
            if (stod(num1) + stod(num2) == 0)
                cout << "\nRESULTS:\n" << negNum1 << " + " << negNum2 << " = " << 0 << "\n";
            else
                cout << "\nRESULTS:\n" << negNum1 << " + " << negNum2 << " = " << (stod(num1) + stod(num2)) << "\n";
        }
        else if (input == "2") // If user chose to subtract
        {
            // Added functionality to make 0 display as 0, as -0 is not really necessary
            // VULNERABILITY FIXED: Subtraction as intended
            if (stod(num1) - stod(num2) == 0)
                cout << "\nRESULTS:\n" << negNum1 << " - " << negNum2 << " = " << 0 << "\n";
            else
                cout << "\nRESULTS:\n" << negNum1 << " - " << negNum2 << " = " << (stod(num1) - stod(num2)) << "\n";
        }
        else if (input == "3") // If user chose to multiply
        {
            // Added functionality to make 0 display as 0, as -0 is not really necessary
            // VULNERABILITY FIXED: Multiplication as intended
            if (stod(num1) * stod(num2) == 0)
                cout << "\nRESULTS:\n" << negNum1 << " * " << negNum2 << " = " << 0 << "\n";
            else
                cout << "\nRESULTS:\n" << negNum1 << " * " << negNum2 << " = " << (stod(num1) * stod(num2)) << "\n";
        }
    }

    return 0;
}